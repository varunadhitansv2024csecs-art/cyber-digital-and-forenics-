exp 6
